cd gogospelnow
venv\Scripts\activate
python main.py
